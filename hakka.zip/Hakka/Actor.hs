module Hakka.Actor (
  ActorPath,
  (//),
  ActorRef,
  Signal (Stop,ChildFailed),
  Message (Message,Signal),
  Envelope (Envelope),
  ActorContext,
  sender,
  self,
  send,
  logMessage,
  Severity (Debug,Info,Warn,Error),
  newActor,
  sendMessage,
  sendSignal,
  Behavior (Behavior,Stopped),
  ActorSystem,
  root,
  stop,
  actorSystem
) where

import Data.List (partition)
import Control.Monad (forM_)
import Control.Concurrent.Chan
import Control.Concurrent (forkIO)
import Control.Exception

--------------------------------------------------------------------------------
-- * Actor Paths and Actor Refs                                               --
--------------------------------------------------------------------------------

data ActorPath =
  RootActorPath { name :: String } |
  ChildActorPath { parent :: ActorPath, name :: String } deriving (Eq)

parentOrRoot (ChildActorPath p _) = p
parentOrRoot root = root

isChildOf :: ActorPath -> ActorPath -> Bool
isChildOf a@(ChildActorPath parent name) b = a == b || isChildOf parent b
isChildOf _ _ = False

instance Show ActorPath where
  show (RootActorPath uri) = uri
  show (ChildActorPath parent s) = (show parent) ++ "/" ++ s

isReserved :: Char -> Bool
isReserved = (flip elem) " /\\\"'"

validateSegment segment =
  if any isReserved segment
    then error $ "segment contains reserved characters: " ++ segment
    else segment

(//) :: ActorPath -> String -> ActorPath
(//) parent = ChildActorPath parent . validateSegment

newtype ActorRef m = ActorRef { actorPath :: ActorPath } deriving Eq

--------------------------------------------------------------------------------
-- * Signals, Messages and Envelopes                                          --
--------------------------------------------------------------------------------

data Signal = Stop | ChildFailed ActorPath String

data Message m = Message m | Signal Signal

data Envelope m = Envelope {
  from :: ActorRef m,
  to :: ActorRef m,
  message :: Message m
}

data SystemMessage m = NewActor {
  path :: ActorPath,
  inbox :: Inbox m
} | ActorTerminated ActorPath | Deliver (Envelope m) | Log ActorPath Severity String

--------------------------------------------------------------------------------
-- * Actors                                                                   --
--------------------------------------------------------------------------------

type Inbox m = Chan (Envelope m)

data ActorContext m = ActorContext {
  sender :: ActorRef m,
  self :: ActorRef m,
  send :: Envelope m -> IO (),
  newActor :: String -> Behavior m -> IO (ActorRef m),
  logMessage :: Severity -> String -> IO ()
}

data Severity = Debug | Info | Warn | Error deriving Show

-- send message from self
sendMessage :: ActorContext m -> ActorRef m -> m -> IO ()
sendMessage context to msg =
  send context $ Envelope (self context) to (Message msg)

-- send signal from self
sendSignal :: ActorContext m -> ActorRef m -> Signal -> IO ()
sendSignal context to sig =
  send context $ Envelope (self context) to (Signal sig)

data Behavior m = Behavior {
  handleMessage :: ActorContext m -> Message m -> IO (Behavior m)
} | Stopped

runActor :: Chan (SystemMessage m) -> Behavior m -> IO (Inbox m)
runActor system behavior = do
  inbox <- newChan
  let loop Stopped = return ()
      loop (Behavior handleMessage) = do
        Envelope sender self payload <- readChan inbox
        let send = writeChan system . Deliver
        let actor name behavior = do
              inbox <- runActor system behavior
              let path = (actorPath self) // name
              writeChan system $ NewActor path inbox
              return $ ActorRef path
        let log s msg = writeChan system $ Log (actorPath self) s msg
        let context = ActorContext sender self send actor log
        let handler e = do
              let path = actorPath self
              let signal = Signal $ ChildFailed path (displayException (e :: SomeException))
              send $ Envelope self (ActorRef (parent path)) signal
              return Stopped
        let calculateNewBehavior = handleMessage context payload
        newBehavior <- catch calculateNewBehavior handler
        loop newBehavior
  forkIO $ loop behavior
  return inbox

--------------------------------------------------------------------------------
-- Actor Systems                                                              --
--------------------------------------------------------------------------------

data ActorSystem m = ActorSystem {
  root :: ActorContext m,
  stop :: IO ()
}

actorSystem :: String -> IO (ActorSystem m)
actorSystem name = do
  system <- newChan
  root <- newChan
  let rootRef = ActorRef (RootActorPath $ validateSegment name)
  let loop actors = do
        msg <- readChan system
        case msg of
          NewActor path inbox -> loop ((path,inbox):actors)
          ActorTerminated path -> do
            let (remove,retain) = partition ((`isChildOf` path) . fst) actors
            forM_ remove $ \(p,a) -> writeChan a $ Envelope rootRef (ActorRef p) (Signal Stop)
            loop retain
          Log path s msg -> do
            putStrLn $ "[" ++ show s ++ "] [" ++ show path ++ "]: " ++ msg
            loop actors
          Deliver msg@(Envelope from to payload) ->
            if to == rootRef
              then case payload of
                Signal Stop -> do
                  putStrLn "System Stopped"
                  return ()
                Signal (ChildFailed p e) -> do
                  putStrLn $ "Actor Failed: " ++ show p
                  writeChan system $ ActorTerminated p
                  loop actors
                Message m -> do
                  putStrLn "plain message delivered to root actor"
                  loop actors
              else case lookup (actorPath to) actors of
                Just recipient -> do
                  writeChan recipient msg
                  loop actors
                Nothing -> do
                  putStrLn $ "message could not be delivered to " ++ (show (actorPath to))
                  loop actors
  forkIO $ loop []
  let send = writeChan system . Deliver
  let actor name behavior = do
        inbox <- runActor system behavior
        let path = (actorPath rootRef) // name
        writeChan system $ NewActor path inbox
        return $ ActorRef path
  let log s msg = writeChan system $ Log (actorPath rootRef) s msg
  let rootContext = ActorContext rootRef rootRef send actor log
  let stopMessage = Envelope rootRef rootRef $ Signal Stop
  let stop = writeChan system $ Deliver stopMessage
  return $ ActorSystem rootContext stop
